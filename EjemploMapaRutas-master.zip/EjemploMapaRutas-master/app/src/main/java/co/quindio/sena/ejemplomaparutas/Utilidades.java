package co.quindio.sena.ejemplomaparutas;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by CHENAO on 25/08/2018.
 */

public class Utilidades {
    public static List<List<HashMap<String, String>>> routes = new ArrayList<List<HashMap<String,String>>>();
    public static Punto coordenadas=new Punto();
}
